#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
int main(int argc, char const *argv[])
{
    int pid = fork();
    int stat1;
    if(pid == 0){
        printf("\nHello I Am Child Process\n");
        int status;
        int pid1 = fork();
        if(pid1 == 0){
            int status1;
            int pid2 = fork();
            if(pid2 == 0){
                int status2;
                int pid3 = fork();
                if(pid3 == 0){
                    printf("\nHello I Am execvp command\n");
                    char* args[] = {"ls","-l","-t","-r",NULL};
                    execvp("ls",args);
                }else{
                    wait(&status2);
                    printf("\nHello I Am execlp command\n");
                    execlp("ls","ls","-l","-t","-r",NULL);
                }
            }else{
                wait(&status1);
                printf("\nHello I Am execv command\n");
                char* args[] = {"ls","-l","-t","-r",NULL};
                execv("/bin/ls",args);
            }
        }else{
            wait(&status);
            printf("Hello I Am execl command\n");
            execl("/bin/ls","ls","-l","-t","-r",NULL);
        }
    }else{
        wait(&stat1);
        printf("Hello I Am Parent Process");
    }
    return 0;
}
