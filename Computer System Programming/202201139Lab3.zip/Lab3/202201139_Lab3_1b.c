#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    int status;
    /*
        Some Program is Passed ./app.out
    */
    pid_t pid = fork();
    if(pid == 0){
        char s[100] = "./";
        strcat(s,argv[1]);
        char* args[] = {s,NULL};
        int a = execv(s,args);
        printf("\nChild Process End\n\n");
    }else{
        int x = wait(&status);
        for(int i = 0 ; i < 26 ; i++){
            printf("%c ",'A'+i);
        }
    }
    return 0;
}
