#include<stdio.h>
#include<stdlib.h>
int factorial(int n){
    if(n==0) return 1;
    return factorial(n-1)*n;
}
int main(int argc, char const *argv[])
{
    int x = atoi(argv[1]);
    int n = atoi(argv[2]);
    double ans = 0;
    double powOfx = 1;
    for(int i = 0 ; i < n ; i++){
        ans += 1.0 * powOfx / factorial(i);
        powOfx *= x;
    }
    printf("%f",ans);
    exit((int)ans);
}
