#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
void multipleOutput(const char* c1,const char* c2){
    int status;
    int pid = fork();

    if(pid == 0){
        const char* c = "202201139_Lab3_expo_child.out";
        char*  args[] = {c ,c1,c2,NULL};
        execv(args[0],args);
    }else{
        wait(&status);
        printf("\n This Childs Status is %d\n",WEXITSTATUS(status));
    }
}
int main(int argc, char const *argv[])
{
    /*
        Here there are 2 arguments one is child process
        1. x (this will be a string so i used atoi to make it a number)
        2. n (number of terms in taylor series)
     */
    
    // number of inputs are 1+2k where there are k n's and k x's
    for(int k = 1 ; k < argc ; k+=2){
        // argv[k] is x other is n
        multipleOutput(argv[k],argv[k+1]);
    }
    
    return 0;
}
