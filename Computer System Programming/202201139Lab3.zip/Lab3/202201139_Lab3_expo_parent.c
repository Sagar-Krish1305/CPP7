#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(int argc, char const *argv[])
{
    /*
        Here there are 2 arguments one is child process
        1. x (this will be a string so i used atoi to make it a number)
        2. n (number of terms in taylor series)
     */
    int status;
    int pid = fork();

    if(pid == 0){
        const char* c = "202201139_Lab3_expo_child.out";
        char*  args[] = {c ,argv[1],argv[2],NULL};
        execv(args[0],args);
    }else{
        wait(&status);
        printf("My Childs Status is %d\n",WEXITSTATUS(status));
    }
    

    return 0;
}
